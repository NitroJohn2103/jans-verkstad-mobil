# Saker publicering

Kod har INTE publicerats och GitHub-repot har INTE andrats.

1. Sakerhetskopiera befintligt repo och exportera nuvarande register till iCloud Drive.
2. Bygg och testa pa separat origin (inte samma `nitrojohn2103.github.io`-origin, eftersom IndexedDB kan delas mellan olika sokvagar).
3. Kontrollera Supabases RLS och privat bucket via `KONTROLL.sql`.
4. Bygg `npm run build`, och lagg enbart byggresultatet `dist/` i det befintliga GitHub Pages-upplagget.
5. Starta uppdaterad hemskarmsapp pa den iPhone som har originalregistret. Kontrollera att alla poster och foton finns kvar INNAN molnet kopplas pa.
6. Logga in i Supabase Auth och exportera en NY backup. Aktivera synk, kontrollera antal, bilder och lagringsutrymme.
7. Forst darefter starta appen pa Mac och hamta molnregistret.

Om test misslyckas: stoppa; lat originalapp och iCloud-backup ligga kvar. Aterstall aldrig en tom fil over ett ifyllt register.
