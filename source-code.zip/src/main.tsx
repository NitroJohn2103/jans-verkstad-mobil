import React from 'react';
import {createRoot} from 'react-dom/client';
import Workshop from './App';
import './style.css';
createRoot(document.getElementById('root')!).render(<Workshop/>);
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
