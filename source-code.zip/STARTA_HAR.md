# Jans verkstad – version 2, arbetskopia

**Den befintliga Jans verkstad ar INTE andrad.** Detta ar hela originalprojektet plus kod for valfri synkronisering via Supabase. Det ar fortfarande en **testversion**, inte en installerad eller publicerad app.

## Vad ar nytt?

- Ursprungsregistret sparas i samma IndexedDB-databas (`jans-verkstad-mobil`) och samma backupformat (JSON version 1).
- Appen kan konfigureras med Supabase projektadress och **publishable/anon key**.
- E-postinloggning via lank och alternativt losenord.
- Molnlagring av foremal, platser och privata foton.
- Lokal ko for andringar utan internet; synkronisering nar appen ar oppen och uppkopplad.
- Knapp for forhandskontroll av antal foremal pa enheten och i molnet fore forsta synkroniseringen.
- Automatisk **STOPP** om molnet och enheten redan har var sitt icke-tomma register.
- Upptackt av vanliga konflikter nar samma post redigerats pa tva enheter.

## Viktigt for Jan

1. Behall den befintliga hemskarmsappen och iCloud-sakerhetskopian ororda.
2. Uppdatera **inte** GitHub Pages med denna ZIP direkt. Kallkoden maste forst byggas och testas.
3. Skicka **aldrig** databaslosenord, `service_role` eller `sb_secret_...` till appen eller i chatten.
4. For att aktivera behovs Supabase **Project URL** och **publishable key** (detta ar *inte* databaslosenordet).
5. Efter byggtest och publikering ska overforingen forst startas i den iPhone-app som redan innehaller verktygen. Borja med en **separat backup** i iCloud Drive.
6. Pa Mac: logga in med samma **Supabase Auth-anvandare** som pa iPhone och hamta registren. Supabase-inloggningen ar skild fran GitHub-inloggningen till Supabases administrationssida.

## Bygg och kontrollera pa Mac

Pa en Mac med Node.js >= 22.16 installerad:

```sh
npm install
npm run check
npm run dev
```

Oppna sidan pa adressen som Vite visar. Anvand **endast testdata** under denna fas. For produktionsbygge: `npm run build`. Utdata hamnar i `dist/`.

**Innan autentiseringstest** fran exempelvis `http://127.0.0.1:5173/` maste exakt testadress laggas till under Supabase > Authentication > URL Configuration > Redirect URLs. Gor inte detta genom att ersatta den befintliga URL:en till Jans verkstad.

**Publicera inte** till det riktiga GitHub Pages-projektet forran testplanen i `docs/TESTPLAN.md` ar godkand. Vid slutlig publicering ska byggda `dist`-filer placeras i GitHub Pages-utgivningsmappen enligt projektets nuvarande publiceringssatt. Detta steg har inte genomforts har.

## Supabase-inställningar

Projektet ska redan innehalla tabellen `public.verkstad_records`, RLS-policyer och privat Storage-bucket `jans-foton`. Koden utgar fran de SQL-kommandon som korts tidigare i chatten.

Kor vid behov `docs/KONTROLL.sql` (endast SELECT) i SQL Editor och kontrollera:
- `rls_aktiverat = true` for `verkstad_records`
- Minst 4 policyer for read/insert/update/delete i tabellen
- `offentliga_foton = false` for `jans-foton`
- Fotopolicyer for read/insert/update/delete i Storage

Skriv **inte** service-role-nycklar i webbkod. Webbsidans URL och publishable key kan lamnas i appens molninstallningar, och sparas endast pa den enheten.

## Begransningar och kvarvarande testbehov

- Den har versionen har kontrollerats **syntaktiskt** men inte byggts med npm, eftersom det inte finns tillgang till pakethamtning i denna miljo.
- Inga riktiga Supabase-anrop eller iPhone/Mac-funktionstester har kunnat koras har. Darfor ar synken INTE klar att borja anvanda i drift.
- Full konfliktlosning/arv av flera redan ifyllda enhetsregister ingar inte. Det ar medvetet stoppat i stallet for att riskera data.
- Fotofiler som ersatts i Storage rensas inte automatiskt bort.
- Gratis Supabase-projekt kan pausas efter inaktivitet.
- Auth via magisk e-postlank kan landa i Safari i stallet for hemskarmsappen. Anvand losenordsinloggning i appen vid behov.
- Uppkopplingsberoende synk sker bara medan appen ar oppen, inte som en permanent bakgrundsprocess iOS.
- Samtidiga uppdateringar av exakt samma post ar inte garanterat atomiskt konfliktfria; sarskilt race-conditioner behover produktionstest.

Originalkod: `src/App.tsx`, `src/local-api.ts`. Tillagda filer: `src/cloud-sync.ts`, `src/CloudPanel.tsx`, `src/cloud-panel.css`.
